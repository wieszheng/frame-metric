# 脚本模板管理页面使用说明

## 访问管理页面

启动 FastAPI 服务后，在浏览器中访问：

```
http://localhost:8000/admin
```

或者访问静态文件：

```
http://localhost:8000/static/admin.html
```

## 功能说明

### 1. 查看脚本模板列表
- 页面加载时自动显示所有脚本模板
- 显示脚本名称、ID、描述、创建时间、更新时间等信息
- 显示代码预览（前200个字符）

### 2. 搜索脚本模板
- 在顶部搜索框输入关键词
- 支持按脚本名称或描述搜索
- 实时过滤显示结果

### 3. 创建脚本模板
- 点击"创建脚本模板"按钮
- 填写脚本名称（必填）
- 填写描述（可选）
- 编写脚本代码（必填）
- 点击"保存"按钮

### 4. 编辑脚本模板
- 在脚本列表中点击"编辑"按钮
- 修改脚本信息或代码
- 点击"保存"按钮

### 5. 删除脚本模板
- 在脚本列表中点击"删除"按钮
- 确认删除操作
- **注意：删除操作不可恢复！**

## 脚本代码编写说明

脚本代码支持完整的 JavaScript/TypeScript 语法，包括：

- 变量声明：`const`, `let`, `var`
- 条件语句：`if/else`, `switch`
- 循环语句：`for`, `while`, `do...while`
- 函数定义：`function`, 箭头函数
- 异步操作：`async/await`, `Promise`

### 可用的辅助函数

- `helpers.log(message)` - 输出日志
- `helpers.sleep(ms)` - 延迟执行（毫秒）
- `helpers.execHdcShell(command)` - 执行 HDC Shell 命令

### 可用的任务对象

- `task.packageName` - 应用包名
- `task.name` - 任务名称
- `task.id` - 任务ID

### 示例脚本

```javascript
// 简单的启动应用脚本
helpers.log('脚本开始执行')
await helpers.sleep(1000)
const result = await helpers.execHdcShell(`am start -n ${task.packageName}/.MainActivity`)
helpers.log(`启动结果: ${result}`)

// 带条件判断的脚本
if (task.packageName) {
    helpers.log(`准备启动应用: ${task.packageName}`)
    await helpers.sleep(500)
    const result = await helpers.execHdcShell(`am start -n ${task.packageName}/.MainActivity`)
    helpers.log(`启动完成: ${result}`)
} else {
    helpers.log('错误: 未指定应用包名')
}

// 循环执行操作
for (let i = 0; i < 3; i++) {
    helpers.log(`第 ${i + 1} 次操作`)
    await helpers.sleep(1000)
}
```

## API 接口

管理页面使用以下 REST API：

- `GET /script-templates` - 获取脚本模板列表
- `GET /script-templates/{id}` - 获取单个脚本模板
- `POST /script-templates` - 创建脚本模板
- `PATCH /script-templates/{id}` - 更新脚本模板
- `DELETE /script-templates/{id}` - 删除脚本模板

## 注意事项

1. 脚本模板 ID 会自动生成，格式为 `script-{timestamp}`
2. 脚本代码会在任务执行时动态下载到本地并执行
3. 修改脚本代码后，下次执行任务时会自动更新本地脚本文件
4. 删除脚本模板前，请确保没有正在使用该模板的任务

