#!/bin/bash

echo "Starting FastAPI Monitoring Persistence Service..."
echo ""

# 检查虚拟环境
if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi

# 激活虚拟环境
source .venv/bin/activate

# 安装依赖
echo "Installing dependencies..."
pip install -r requirements.txt -q

# 启动服务
echo ""
echo "Starting server on http://127.0.0.1:8000"
echo "API docs: http://127.0.0.1:8000/docs"
echo ""
uvicorn main:app --reload --host 0.0.0.0 --port 8000

