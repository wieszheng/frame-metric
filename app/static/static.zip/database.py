"""数据库配置和会话管理（异步版本）"""
import os
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase

DB_PATH = os.getenv("METRICS_DB_PATH", os.path.join("data", "metrics.db"))

# 确保数据库目录存在
db_dir = os.path.dirname(DB_PATH)
if db_dir and not os.path.exists(db_dir):
    os.makedirs(db_dir, exist_ok=True)

# SQLite 异步数据库 URL（使用 aiosqlite）
SQLALCHEMY_DATABASE_URL = f"sqlite+aiosqlite:///{DB_PATH}"

# 创建异步引擎
engine = create_async_engine(
    SQLALCHEMY_DATABASE_URL,
    echo=False,  # 设置为 True 可以看到 SQL 日志
    future=True
)

# 创建异步会话工厂
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)


# SQLAlchemy 2.0 声明基类
class Base(DeclarativeBase):
    pass


async def get_db():
    """依赖注入：获取异步数据库会话"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db():
    """初始化数据库表（异步）"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

