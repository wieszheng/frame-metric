# 监控数据持久化服务

基于 FastAPI + SQLAlchemy 的监控数据持久化服务，提供任务和监控样本的完整存储与查询功能。

## 功能特性

- ✅ **任务管理**：完整的任务 CRUD 操作
- ✅ **监控样本存储**：高性能的监控数据持久化
- ✅ **SQLAlchemy ORM**：使用 SQLAlchemy 进行数据库操作
- ✅ **RESTful API**：标准的 REST API 接口
- ✅ **数据统计**：任务摘要查询（包含样本统计）

## 技术栈

- **FastAPI** 0.115.0：现代、快速的 Web 框架
- **SQLAlchemy** 2.0.36：Python ORM 框架
- **SQLite**：轻量级数据库（可替换为 PostgreSQL/MySQL）

## 安装与运行

### 1. 安装依赖

```bash
cd server/fastapi
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. 启动服务

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

服务启动后，访问：
- **API 文档**：http://127.0.0.1:8000/docs
- **健康检查**：http://127.0.0.1:8000/health

### 3. 环境变量（可选）

```bash
# 自定义数据库路径（默认：data/metrics.db）
export METRICS_DB_PATH=/path/to/your/database.db
```

## API 接口

### 任务管理

#### 创建任务
```http
POST /tasks
Content-Type: application/json

{
  "id": "task-001",
  "name": "登录流程监控",
  "packageName": "com.example.app",
  "scriptTemplateId": "login-flow",
  "metrics": ["cpu", "memory", "fps"],
  "monitorConfig": {
    "interval": 1,
    "enableAlerts": true,
    "thresholds": {
      "fpsWarning": 30,
      "fpsCritical": 20
    }
  }
}
```

#### 查询任务列表
```http
GET /tasks?status=running&limit=10&offset=0
```

#### 查询任务摘要（含统计信息）
```http
GET /tasks/summary?status=running&limit=10
```

#### 获取单个任务
```http
GET /tasks/{task_id}
```

#### 更新任务
```http
PATCH /tasks/{task_id}
Content-Type: application/json

{
  "status": "running",
  "monitorConfig": {
    "interval": 2
  }
}
```

#### 删除任务
```http
DELETE /tasks/{task_id}
```

### 监控样本

#### 创建监控样本
```http
POST /metrics
Content-Type: application/json

{
  "taskId": "task-001",
  "sample": {
    "timestamp": 1703123456789,
    "cpu": 45.5,
    "memory": 256.0,
    "appCpuUsage": 30.2,
    "appMemoryUsage": 128.5,
    "fps": 60,
    "gpuLoad": 50.0,
    "deviceTemperature": 35.5,
    "performanceScore": {
      "overall": 85,
      "fpsScore": 100,
      "cpuScore": 70,
      "memoryScore": 80,
      "temperatureScore": 90,
      "powerScore": 75,
      "grade": "Good"
    }
  }
}
```

#### 查询任务的监控样本
```http
GET /metrics?task_id=task-001&limit=200&offset=0
```

#### 获取单个监控样本
```http
GET /metrics/{metric_id}
```

## 数据库结构

### tasks 表
- `id` (String, PK)：任务 ID
- `name` (String)：任务名称
- `package_name` (String)：应用包名
- `script_template_id` (String)：脚本模板 ID
- `metrics` (JSON)：监控指标列表
- `status` (String)：任务状态
- `monitor_config` (JSON)：监控配置
- `created_at` (Integer)：创建时间戳（毫秒）
- `updated_at` (Integer)：更新时间戳（毫秒）

### metrics 表
- `id` (Integer, PK, Auto)：样本 ID
- `task_id` (String, Index)：任务 ID
- `timestamp` (Integer)：采样时间戳（毫秒）
- `cpu`, `memory`, `app_cpu_usage`, `app_memory_usage`, `fps`, `gpu_load`, `device_temperature`, `power_consumption`, `network_up_speed`, `network_down_speed` 等指标字段
- `performance_score` (JSON)：性能评分

## 数据精度

为了优化存储空间，部分浮点数值在存储时转换为整数：

- **百分比**（CPU、内存等）：`值 * 100` 存储，读取时 `/ 100`
- **FPS 稳定性**：`值 * 1000` 存储（毫秒精度），读取时 `/ 1000`
- **功耗**：`值 * 1000` 存储（毫瓦），读取时 `/ 1000`
- **温度**：`值 * 10` 存储（0.1°C 精度），读取时 `/ 10`

## 集成到 Electron

Electron 主进程会自动将任务和监控样本同步到 FastAPI 服务：

- 创建任务时自动调用 `POST /tasks`
- 更新任务状态时自动调用 `PATCH /tasks/{id}`
- 采集监控样本时自动调用 `POST /metrics`

可通过环境变量 `FASTAPI_ENDPOINT` 配置服务地址（默认：`http://127.0.0.1:8000`）。

## 开发建议

### 生产环境部署

1. **更换数据库**：将 SQLite 替换为 PostgreSQL 或 MySQL
   ```python
   # database.py
   SQLALCHEMY_DATABASE_URL = "postgresql://user:pass@localhost/dbname"
   ```

2. **添加认证**：使用 FastAPI 的 `HTTPBearer` 或 OAuth2
3. **添加日志**：集成 `logging` 或 `structlog`
4. **性能优化**：使用连接池、批量插入等

### 数据迁移

如果需要从旧版本迁移数据，可以编写迁移脚本：

```python
# migrate.py
from sqlalchemy import create_engine, text

old_db = create_engine("sqlite:///old.db")
new_db = create_engine("sqlite:///new.db")

# 迁移逻辑...
```
